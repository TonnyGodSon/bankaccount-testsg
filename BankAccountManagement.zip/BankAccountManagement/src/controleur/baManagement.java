package controleur;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import bankaccount.BankAccount;

/**
 * Bank account management
 * @author antoine m
 *
 */
public class baManagement {

	public static void main(String[] args) {
		int choice = 0;
		BankAccount myAccount = new BankAccount();
		List<String> listOfOperations = new ArrayList<String>();
		
		System.out.println("***** WELCOME TO YOUR FAVORITE BANK *****");
		System.out.println("Please, select your operation : ");
		System.out.println(""
				+ "1) Making a deposit in your banck account.\n"
				+ "2) Making a withdrawal from your banck account.\n"
				+ "3) Checking my operation history.\n"
				+ "4) Terminated!");
		Scanner sc = new Scanner(System.in);
		String choiceText = sc.nextLine();
		choice = Integer.parseInt(choiceText);
		
		while(choice < 5 && choice > 0) {
			if(choice == 1) {
				System.out.println("How many do you want to add to your bank account ?");
				String text = sc.nextLine();
				Double amount = Double.parseDouble(text);
				double amountToAdd = amount;
				myAccount.deposit(amountToAdd);
				String message = ""+myAccount.getDate()+" - Deposit of "+amountToAdd+"� ;";
				System.out.println(message);
				System.out.println("--\nYour balance : "+myAccount.getBalance()+" �.");
				listOfOperations.add(message);
				myAccount.setListOfOp(listOfOperations);
				
				System.out.println("\nPlease, select another operation :");
				choiceText = sc.nextLine();
				choice = Integer.parseInt(choiceText);
			}
			
			if(choice == 2) {
				System.out.println("How many do you want to retrieve from your bank account ?");
				String text = sc.nextLine();
				Double amount = Double.parseDouble(text);
				double amountToRetrieve = amount;
				myAccount.withdrawal(amountToRetrieve);
				String message = ""+myAccount.getDate()+" - Withdrawal of "+amountToRetrieve+"� ;";
				System.out.println(message);
				System.out.println("--\nYour balance : "+myAccount.getBalance()+" �.");
				listOfOperations.add(message);
				myAccount.setListOfOp(listOfOperations);
				
				System.out.println("\nPlease, select another operation :");
				choiceText = sc.nextLine();
				choice = Integer.parseInt(choiceText);
			}
			
			if(choice == 3) {
				System.out.println("List of your last operations :");
				for(String op : myAccount.getListOfOp()) {
					System.out.println(op);
				}
				System.out.println("--\n"
						+ "Your balance : "+myAccount.getBalance()+" �.");
				
				System.out.println("\nPlease, select another operation :");
				choiceText = sc.nextLine();
				choice = Integer.parseInt(choiceText);
			}
			
			if(choice == 4) {
				System.out.println("Operation terminated !");
				break;
			}
		};
		
		if(choice > 4 || choice < 0){
			System.out.println("Wrong choice. Please, retry!");
		}
	}
}

package bankaccount;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class BankAccount {
	
	private String date;
	private double amount;
	private double balance;
	private List<String> listOfOp = new ArrayList<>();

	/**
	 * constructor
	 */
	public BankAccount() {
		Calendar c = Calendar.getInstance();
		int year = c.get(Calendar.YEAR);
		int month = c.get(Calendar.MONTH);
		int day = c.get(Calendar.DAY_OF_MONTH);
		int hour = c.get(Calendar.HOUR_OF_DAY);
		int minute = c.get(Calendar.MINUTE);
		this.date = ""+day+"/"+month+"/"+year+" at "+hour+"H"+minute;
		this.amount = 0;
		this.balance = 0;
		this.listOfOp.add("No operation until now.");
	}
	
	public double deposit(double addAmount) {
		this.balance+=addAmount;
		return this.balance;
	}
	
	public double withdrawal(double retrieveAmount) {
		this.balance-=retrieveAmount;
		return this.balance;
	}

	/**
	 * @return the date
	 */
	public String getDate() {
		return date;
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * @return the amount
	 */
	public double getAmount() {
		return amount;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(double amount) {
		this.amount = amount;
	}

	/**
	 * @return the balance
	 */
	public double getBalance() {
		return balance;
	}

	/**
	 * @param balance the balance to set
	 */
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	/**
	 * @return the listOfOp
	 */
	public List<String> getListOfOp() {
		return listOfOp;
	}

	/**
	 * @param listOfOp the listOfOp to set
	 */
	public void setListOfOp(List<String> listOfOp) {
		this.listOfOp = listOfOp;
	}

}
